/*
    Douglas Humbero Alvarado Morales
    IN5AV
    2022037
    Fecha de cración:
        31-03-2023
    Fecha de modificaciones:
        31-03-2023
 */
package org.douglasalvarado.main;

/**
 *
 * @author Douglas
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Entidad enti = new Entidad(); //Declaramos un objero de tipo Entidad   
        enti.Todo();
    }
}