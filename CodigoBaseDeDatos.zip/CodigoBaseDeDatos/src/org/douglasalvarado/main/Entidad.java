package org.douglasalvarado.main;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Douglas
 */
public class Entidad {
    //Declaración de variable
    private int op = 0; //variable de opción
    private int cantidadA = 0; //Cantidad de atributos que tendra la entidad
    private int cantidadF = 0; //Creamos la variable para saber cuantas foraneas
    private int maximo = 0; //Creamos la varianble para llevar un conteo de cuantos atributos hay
    private int maximoF = 0; //Creamos la varianble para llevar un conteo de cuantas foraneas hay
    private String alias = ""; //Creamos la variable para el alias
    private String nombreEntidad = ""; //Creamos la variable para el nombre de la entidad
    private String nombreEntidadF = ""; //Creamos la variable para el nombre de la entidad
    private String caracter = ""; //Creamos la variable para la asignacion de caracter
    private boolean close = true; //variable para el ciclo while
    private char foraneaE; //Creamos la variable para las llaves foraneas
        
    private Scanner leer = new Scanner(System.in); //Declaracion del objeto de tipo Scanner
    private String regex = "^\\d+(\\.\\d+)?$"; //Creamos la variable de expresion regular para la validacion de Decimal (No entendi ni madres)

    //Generamos los ArrayList para guardar los atributos
    private ArrayList<String> idAtributos = new ArrayList<String>(); //Guardamos el nombre del atributo
    private ArrayList<String> idForaneas = new ArrayList<String>(); //Guardamos el nombre de la entida
    private ArrayList<String> idAtributoForanea = new ArrayList<String>(); //Guardamos el nombre del atributo foraneas
    private ArrayList<Character> tipoAtributos = new ArrayList<Character>(); //Guardamos el tipo de dato del atributo
    private ArrayList<Character> tipoForanea = new ArrayList<Character>(); //Guardamos el tipo de dato de la foranea
    private ArrayList<Character> nuloNo = new ArrayList<Character>(); //Guardamos si el atributo puede ser nulo o no
    private ArrayList<Double> cantidaVD = new ArrayList<Double>(); //Guardamos la cantidad del Varchar o Decimal
    private ArrayList<Double> cantidaVDForanea = new ArrayList<Double>(); //Guardamos la cantidad del Varchar o Decimal Foraneo
    
    public Entidad() {
    }
    
    public void Todo(){
        while (close == true) { //Ciclo while para poder ejecutar el codigo más de 1 vez
            Opciones();
            switch (op) {
                case 1:
                    Caso1();
                    break;
                case 2:
                    Caso2();
                    break;
                case 5:
                    close = false;
                    break;
                default:
                    System.out.println("Siga Instrucciones");
                    throw new AssertionError();
            }
        }  
    }
    
    private void UnidorProcedimientos(String nombreEntidad,int maximo ,String caracter, ArrayList<String> idAtributos, 
            ArrayList<Character> tipoAtributos, ArrayList<Double> cantidaVD){
        
        procedimientoAlmcenadoCrear(nombreEntidad, maximo, idAtributos, tipoAtributos, cantidaVD);
        procedimientoAlmcenadoActualizar(nombreEntidad, maximo, caracter, idAtributos, tipoAtributos, cantidaVD);
        procedimientoAlmcenadoListar(nombreEntidad, maximo, idAtributos);
        procedimientoAlmcenadoBuscar(nombreEntidad, maximo, caracter, idAtributos, tipoAtributos);
        procedimientoAlmcenadoEliminar(nombreEntidad, caracter, idAtributos, tipoAtributos);
    }
    
    private void Entidad(ArrayList<String> tablaForanea, String nombreEntidad,int maximo, int maximoF, 
            ArrayList<String> idAtributos, ArrayList<String> idAtributosForaneas, ArrayList<Character> tipoAtributos, 
            ArrayList<Character> tipoForanea, ArrayList<Character> nuloNo, ArrayList<Double> cantidaVD, 
            ArrayList<Double> cantidaVDForaneo, char si){
        System.out.println("");
        if ("s".equals(nombreEntidad.substring(nombreEntidad.length()-1,nombreEntidad.length())) || 
                "S".equals(nombreEntidad.substring(nombreEntidad.length()-1,nombreEntidad.length()))) 
            System.out.println("Create table "+(nombreEntidad.substring(0, nombreEntidad.length()-1))+"(");
        else
            System.out.println("Create table "+nombreEntidad+"(");
        for (int i = 0; i < maximo; i++) {
            if (idAtributos.get(i).substring(0,2).equals("codigo")) {
                System.out.print("    "+idAtributos.get(i));
                if (Comparador(tipoAtributos.get(i)).equals("varchar")||Comparador(tipoAtributos.get(i)).equals("decimal")) 
                System.out.print(" "+Comparador(tipoAtributos.get(i))+" ("
                        +String.valueOf(cantidaVD.get(i)).substring(0,String.valueOf(cantidaVD.get(i)).length()-2)+") ");
                else
                    System.out.print(" "+Comparador(tipoAtributos.get(i)));
                System.out.print(" "+Nulo(nuloNo.get(i))+"auto_increment,");
                System.out.println("");
            }else{
            System.out.print("    "+idAtributos.get(i));
            if (Comparador(tipoAtributos.get(i)).equals("varchar")||Comparador(tipoAtributos.get(i)).equals("decimal")) 
                System.out.print(" "+Comparador(tipoAtributos.get(i))+" ("
                        +String.valueOf(cantidaVD.get(i)).substring(0,String.valueOf(cantidaVD.get(i)).length()-2)+") ");
            else
                System.out.print(" "+Comparador(tipoAtributos.get(i)));
            System.out.print(" "+Nulo(nuloNo.get(i)));
            System.out.print(",\n");
            }
        }
        if (si=='Y'){
            for (int i = 0; i < maximoF; i++) {
                System.out.print("    codigo"+idAtributosForaneas.get(i));
                if (Comparador(tipoForanea.get(i)).equals("varchar")|| Comparador(tipoForanea.get(i)).equals("decimal")) {
                    System.out.print(" "+Comparador(tipoForanea.get(i))+" ("
                        +String.valueOf(cantidaVDForaneo.get(i)).substring(0,String.valueOf(cantidaVDForaneo.get(i)).length()-2)+")");
                }else
                    System.out.print(" "+Comparador(tipoForanea.get(i)));
                System.out.print(" not null,\n");
            }
        }
        
        System.out.print("\n    primary key PK_"+idAtributos.get(0)+" ("+idAtributos.get(0)+")");
        if (si=='Y') {
            System.out.print(",");
            for (int i = 0; i < maximoF; i++) {
                System.out.print("\n    constraint FK_"+nombreEntidad+"_"+tablaForanea.get(i)+
                        " foreing key ("+idAtributosForaneas.get(i)+")"+
                        "\n        references "+tablaForanea.get(i)+"("+idAtributosForaneas.get(i)+")");
            }
        }
        System.out.println("\n);");
    }
    
    private void procedimientoAlmcenadoCrear(String nombreEntidad,int maximo, ArrayList<String> idAtributos, 
            ArrayList<Character> tipoAtributos, ArrayList<Double> cantidaVD){
        System.out.println("");
        System.out.println("-- -------------- PROCEDIMIENTO ALMACENADOS ---------------");
        System.out.println("-- -------------- "+nombreEntidad+" ---------------");
        alias = nombreEntidad.substring(0,1);
        if ("s".equals(nombreEntidad.substring(nombreEntidad.length()-1,nombreEntidad.length())) || 
                "S".equals(nombreEntidad.substring(nombreEntidad.length()-1,nombreEntidad.length()))) 
            System.out.println("-- Crear "+(nombreEntidad.substring(0, nombreEntidad.length()-1)));
        else
            System.out.print("\n-- Crear "+nombreEntidad);
        System.out.print("Delimiter $$");
        if ("s".equals(nombreEntidad.substring(nombreEntidad.length()-1,nombreEntidad.length())) || 
                "S".equals(nombreEntidad.substring(nombreEntidad.length()-1,nombreEntidad.length()))) 
            System.out.print("\n    Create procedure sp_Crear"+(nombreEntidad.substring(0, nombreEntidad.length()-1))+"(");
        else
            System.out.print("\n    Create procedure sp_Crear"+nombreEntidad+"(");
        for (int i = 1; i < maximo; i++) {
        System.out.print("in "+idAtributos.get(i));
            if (Comparador(tipoAtributos.get(i)).equals("varchar")||Comparador(tipoAtributos.get(i)).equals("decimal")) {
                if (i==maximo) 
                    System.out.print(" "+Comparador(tipoAtributos.get(i))+" ("
                        +String.valueOf(cantidaVD.get(i)).substring(0,String.valueOf(cantidaVD.get(i)).length()-2)+")");
                else
                    System.out.print(" "+Comparador(tipoAtributos.get(i))+" ("
                        +String.valueOf(cantidaVD.get(i)).substring(0,String.valueOf(cantidaVD.get(i)).length()-2)+"),");
            }
            else
                if (i+1<maximo) 
                    System.out.print(" "+Comparador(tipoAtributos.get(i))+",");
                else
                    System.out.print(" "+Comparador(tipoAtributos.get(i)));
        }
        //Checar esos espacios raros 
        System.out.print(")");
        System.out.print("\n        Begin");
        System.out.print("\n            Insert into "+nombreEntidad+" (");
        for (int i = 1; i < maximo; i++) {
            System.out.print(idAtributos.get(i));
        if (i+1<maximo) 
            System.out.print(", ");
        }
        System.out.print(")");
        System.out.print("\n                values (");
        for (int i = 1; i < maximo; i++) {
            System.out.print(idAtributos.get(i));
        if (i+1<maximo) 
            System.out.print(", ");
        }
        System.out.print(");");
        System.out.println("");
        System.out.println("        End$$");
        System.out.println("Delimiter ;");
        if ("s".equals(nombreEntidad.substring(nombreEntidad.length()-1,nombreEntidad.length())) || 
                "S".equals(nombreEntidad.substring(nombreEntidad.length()-1,nombreEntidad.length()))) 
            System.out.println("call sp_Crear"+(nombreEntidad.substring(0, nombreEntidad.length()-1))+"( );");
        else
            System.out.println("call sp_Crear"+nombreEntidad+"( );");
        System.out.println("");
    }
    //Hacer los demas procedimientos
    private void procedimientoAlmcenadoActualizar(String nombreEntidad,int maximo,String caracter, ArrayList<String> idAtributos, 
            ArrayList<Character> tipoAtributos, ArrayList<Double> cantidaVD){
        alias = nombreEntidad.substring(0,1);
        if ("s".equals(nombreEntidad.substring(nombreEntidad.length()-1,nombreEntidad.length())) || 
                "S".equals(nombreEntidad.substring(nombreEntidad.length()-1,nombreEntidad.length()))) 
            System.out.println("-- Actualizar "+(nombreEntidad.substring(0, nombreEntidad.length()-1)));
        else
            System.out.print("\n-- Actualizar "+nombreEntidad);
        System.out.print("Delimiter $$");
        if ("s".equals(nombreEntidad.substring(nombreEntidad.length()-1,nombreEntidad.length())) || 
                "S".equals(nombreEntidad.substring(nombreEntidad.length()-1,nombreEntidad.length()))) 
            System.out.print("\n    Create procedure sp_Actualizar"+(nombreEntidad.substring(0, nombreEntidad.length()-1))+"(");
        else
            System.out.print("\n    Create procedure sp_Actualizar"+nombreEntidad+"(");
        for (int i = 0; i < maximo; i++) {
        System.out.print("in "+idAtributos.get(i)+caracter);
            if (Comparador(tipoAtributos.get(i)).equals("varchar")) {
                if (i+1<maximo) 
                    System.out.print(" "+Comparador(tipoAtributos.get(i))+" ("
                        +String.valueOf(cantidaVD.get(i)).substring(0,String.valueOf(cantidaVD.get(i)).length()-2)+"),");
                else
                    System.out.print(" "+Comparador(tipoAtributos.get(i))+" ("
                        +String.valueOf(cantidaVD.get(i)).substring(0,String.valueOf(cantidaVD.get(i)).length()-2)+")");
            }else if (Comparador(tipoAtributos.get(i)).equals("decimal")) {
                if (i+1<maximo) 
                    System.out.print(" "+Comparador(tipoAtributos.get(i))+" ("
                        +String.valueOf(cantidaVD.get(i))+"),");
                else
                    System.out.print(" "+Comparador(tipoAtributos.get(i))+" ("
                        +String.valueOf(cantidaVD.get(i))+")");
            } else
                if (i+1<maximo) 
                    System.out.print(" "+Comparador(tipoAtributos.get(i))+",");
                else
                    System.out.print(" "+Comparador(tipoAtributos.get(i)));
        }
        //Checar esos espacios raros 
        System.out.print(")");
        System.out.print("\n        Begin");
        System.out.print("\n            Update "+nombreEntidad+" "+alias+"\n              Set");
        for (int i = 1; i < maximo; i++) {    
        System.out.print("\n                "+alias+"."+idAtributos.get(i)+" = "+idAtributos.get(i)+caracter);
            if (i+1<maximo) 
                System.out.print(",");
        }
        System.out.print("\n                where "+alias+"."+idAtributos.get(0)+" = "+idAtributos.get(0)+caracter);
        System.out.print(";");
        System.out.println("");
        System.out.println("        End$$");
        System.out.println("Delimiter ;");
        if ("s".equals(nombreEntidad.substring(nombreEntidad.length()-1,nombreEntidad.length())) || 
                "S".equals(nombreEntidad.substring(nombreEntidad.length()-1,nombreEntidad.length()))) 
            System.out.println("call sp_Actualizar"+(nombreEntidad.substring(0, nombreEntidad.length()-1))+"( );");
        else
            System.out.println("call sp_Actualizar"+nombreEntidad+"( );");
    }
    
    private void procedimientoAlmcenadoListar(String nombreEntidad,int maximo,ArrayList<String> idAtributos){
        alias = nombreEntidad.substring(0,1);
        System.out.println("");
        if ("s".equals(nombreEntidad.substring(nombreEntidad.length()-1,nombreEntidad.length())) || 
                "S".equals(nombreEntidad.substring(nombreEntidad.length()-1,nombreEntidad.length()))) 
            System.out.println("-- Listar "+nombreEntidad);
        else
            System.out.println("-- Listar "+nombreEntidad+"s");
        System.out.println("Delimiter $$");
        if ("s".equals(nombreEntidad.substring(nombreEntidad.length()-1,nombreEntidad.length())) || 
                "S".equals(nombreEntidad.substring(nombreEntidad.length()-1,nombreEntidad.length()))) 
            System.out.print("    Create procedure sp_Listar"+nombreEntidad+"()");
        else
            System.out.print("    Create procedure sp_Listar"+nombreEntidad+"s()");
        System.out.println("\n        Begin");
        System.out.println("            Select");
        for (int i = 0; i < maximo; i++) {
        System.out.print("                "+alias+"."+idAtributos.get(i));
            if (i+1<maximo) 
                System.out.println(",");
            else
                System.out.println("");
        }
        System.out.println("                    from "+nombreEntidad+" "+alias+";");
        System.out.println("        End$$");
        System.out.println("Delimiter ;");
        
        if ("s".equals(nombreEntidad.substring(nombreEntidad.length()-1,nombreEntidad.length())) || 
                "S".equals(nombreEntidad.substring(nombreEntidad.length()-1,nombreEntidad.length()))) 
            System.out.println("call sp_Listar"+nombreEntidad+"();");
        else
            System.out.println("call sp_Listar"+nombreEntidad+"s();");
    }
    
    private void procedimientoAlmcenadoBuscar(String nombreEntidad,int maximo, String caracter, 
            ArrayList<String> idAtributos, ArrayList<Character> tipoAtributos){
        alias = nombreEntidad.substring(0,1);
        System.out.println("");
        if ("s".equals(nombreEntidad.substring(nombreEntidad.length()-1,nombreEntidad.length())) || 
                "S".equals(nombreEntidad.substring(nombreEntidad.length()-1,nombreEntidad.length()))) 
            System.out.println("-- Buscar "+(nombreEntidad.substring(0, nombreEntidad.length()-1)));
        else
            System.out.println("-- Buscar "+nombreEntidad);
        System.out.println("Delimiter $$");
        if ("s".equals(nombreEntidad.substring(nombreEntidad.length()-1,nombreEntidad.length())) || 
                "S".equals(nombreEntidad.substring(nombreEntidad.length()-1,nombreEntidad.length()))) 
            System.out.println("    Create procedure sp_Buscar"+(nombreEntidad.substring(0, nombreEntidad.length()-1))+
                    "(in "+idAtributos.get(0)+caracter+" "+Comparador(tipoAtributos.get(0))+")");
        else
            System.out.println("    Create procedure sp_Buscar"+nombreEntidad+"(in "+idAtributos.get(0)+caracter+
                " "+Comparador(tipoAtributos.get(0))+")");
        System.out.println("        Begin");
        System.out.println("            Select");
        for (int i = 0; i < maximo; i++) {
        System.out.print("                "+alias+"."+idAtributos.get(i));
            if (i+1<maximo) 
                System.out.println(",");
            else
                System.out.println("");
        }
        System.out.println("                from "+nombreEntidad+" "+alias);
        System.out.println("                    where "+alias+"."+idAtributos.get(0)+" = "+idAtributos.get(0)+caracter+";");
        System.out.println("        End$$");
        System.out.println("Delimiter ;");
        
        if ("s".equals(nombreEntidad.substring(nombreEntidad.length()-1,nombreEntidad.length())) || 
                "S".equals(nombreEntidad.substring(nombreEntidad.length()-1,nombreEntidad.length()))) 
            System.out.println("call sp_Buscar"+(nombreEntidad.substring(0, nombreEntidad.length()-1))+"( );");
        else
            System.out.println("call sp_Buscar"+nombreEntidad+"( );");
    }
    
    private void procedimientoAlmcenadoEliminar(String nombreEntidad,String caracter,
            ArrayList<String> idAtributos, ArrayList<Character> tipoAtributos){
        alias = nombreEntidad.substring(0,1);
        System.out.println("");
        if ("s".equals(nombreEntidad.substring(nombreEntidad.length()-1,nombreEntidad.length())) || 
                "S".equals(nombreEntidad.substring(nombreEntidad.length()-1,nombreEntidad.length()))) 
            System.out.println("-- Eliminar "+(nombreEntidad.substring(0, nombreEntidad.length()-1)));
        else
            System.out.println("-- Eliminar "+nombreEntidad);
        System.out.println("Delimiter $$");
        if ("s".equals(nombreEntidad.substring(nombreEntidad.length()-1,nombreEntidad.length())) || 
                "S".equals(nombreEntidad.substring(nombreEntidad.length()-1,nombreEntidad.length()))) 
            System.out.print("    Create procedure sp_Eliminar"+(nombreEntidad.substring(0, nombreEntidad.length()-1))
                    +"(in "+idAtributos.get(0)+caracter+" "+Comparador(tipoAtributos.get(0))+")");
        else
            System.out.print("    Create procedure sp_Eliminar"+nombreEntidad+"(in "+idAtributos.get(0)+caracter+
                " "+Comparador(tipoAtributos.get(0))+")");
        System.out.println("\n        Begin");
        System.out.println("            Delete from "+nombreEntidad+" "+alias);
        System.out.println("               where "+alias+"."+idAtributos.get(0)+" = "+idAtributos.get(0)+caracter+";");
        System.out.println("        End$$");
        System.out.println("Delimiter ;");
        if ("s".equals(nombreEntidad.substring(nombreEntidad.length()-1,nombreEntidad.length())) || 
                "S".equals(nombreEntidad.substring(nombreEntidad.length()-1,nombreEntidad.length()))) 
            System.out.println("call sp_Eliminar"+(nombreEntidad.substring(0, nombreEntidad.length()-1))+"( );");
        else
            System.out.println("call sp_Eliminar"+nombreEntidad+"( );");
        System.out.println("");
    }
        
    private String Comparador(char tipo){
        if (tipo == 'V') 
            return "varchar";
        if (tipo == 'I')
            return "int";
        if (tipo == 'D') 
            return "decimal";
        if (tipo == 'T') 
            return "time";
        if (tipo == 'F') 
            return "date";
        else
            return "";
    }
    
    private String Nulo(char nulo){
        if (nulo == 'N')
            return "not null";
        else
            return "";
    }
    
    private char UnCaracter(){
        String tipo = leer.nextLine();
        char retorna = 'a';
        while (tipo.length() != 1) {            
            System.out.println("Porfavor siga instrucciones");
            tipo = leer.nextLine();
        }
        retorna = tipo.charAt(0);
        retorna = Character.toUpperCase(retorna);
        return retorna;
    }
    
    private double ValidacionDouble(){
        String input = "";
        double retorno = 0.00;
        do {
            System.out.println("Ingrese la cantidad");
            input = leer.nextLine().trim();
            if (!input.matches(regex)) 
                System.out.println("No es una cantidad");
            else{
                try{
                    retorno = Double.parseDouble(input);
                }catch(NumberFormatException error){
                    System.out.println("El valor ingresado no \nes un valor decimal");
                }
            }
        } while (!input.matches(regex));
        return retorno;
    }
    
    public void TipoDato(){
        System.out.println("I = int");
        System.out.println("V = Varchar");
        System.out.println("D = Decial");
        System.out.println("T = Time");
        System.out.println("F = Date");
    }
    
    private void Limpieza(ArrayList<String> tablaForanea, String nombreEntidad,int maximo, int maximoF, 
            ArrayList<String> idAtributos, ArrayList<String> idAtributosForaneas, ArrayList<Character> tipoAtributos, 
            ArrayList<Character> tipoForanea, ArrayList<Character> nuloNo, ArrayList<Double> cantidaVD, 
            ArrayList<Double> cantidaVDForaneo, char si){
        tablaForanea.clear();
        nombreEntidad = "";
        maximo = 0;
        maximoF = 0; 
        LimpiezaArray(idAtributos);
        LimpiezaArray(idAtributosForaneas);
        LimpiezaArray(tipoAtributos);
        LimpiezaArray(tipoForanea);
        LimpiezaArray(nuloNo);
        LimpiezaArray(cantidaVD);
        LimpiezaArray(cantidaVDForaneo);
        si = 'a';
    }
    
    private void LimpiezaArray(ArrayList lista){
        while(lista.isEmpty()){
            for (int i = 0; i < 100; i++) {
                if (lista.isEmpty()) 
                    break;
                lista.remove(i);
            }
        }
    }
    
    private void Opciones(){
        System.out.println("Ingrese que desea ejecutar:");
        System.out.println("1. Entidad");
        System.out.println("2. Procedimiento Almacenado");
        System.out.println("5. Salir");
        op = leer.nextInt();
    }
    
    private void Caso1(){
        leer.nextLine();
        System.out.println("---Entidad---");
        System.out.println("---Nombre de la entidad---");
        nombreEntidad = leer.nextLine();
        System.out.println("Ingrese la cantidad de atributos");
        cantidadA = leer.nextInt();
        leer.nextLine();
        System.out.println("Solo ingrese los atributos y llave");
        System.out.println("primaria (de primero llave primaria)");
        System.out.println("no llaves foraneas");
        TipoDato();
        while (cantidadA != 0) {                        
            System.out.println("Nombre del atributo");
            idAtributos.add(leer.nextLine());
            System.out.println("Tipo de atributo");
            char tipo = UnCaracter();
            tipo = Character.toUpperCase(tipo);
            tipoAtributos.add(tipo);
            if (tipo == 'V') {
                cantidaVD.add(ValidacionDouble());
            }else if (tipo == 'D') {
                cantidaVD.add(ValidacionDouble());
            }else
                cantidaVD.add(0.00);
            System.out.println("Es nulo?");
            System.out.println("Y/N");
            nuloNo.add(UnCaracter());
            cantidadA--;
            maximo++;
        }
        System.out.println("posee variable foraneas?");
        System.out.println("Y/N");
        foraneaE = UnCaracter();
        if (foraneaE=='Y') {

            System.out.println("Ingrese la cantidad de");
            System.out.println("atributos foraneas");
            cantidadF = leer.nextInt();
            leer.nextLine();
            while (cantidadF != 0) {                        
                System.out.println("Ingrese el nombre de la");
                System.out.println("entidad de union");
                idForaneas.add(leer.nextLine());
                System.out.println("Ingrese el nombre de la ");
                System.out.println("variable que ara la union");
                System.out.println("(no hay necesidad del ID)");
                idAtributoForanea.add(leer.nextLine());
                System.out.println("tipo de variable");
                System.out.println("siempre respetando lo ");
                System.out.println("mencionado anteriormente");
                char tipo = UnCaracter();
                tipo = Character.toUpperCase(tipo);
                tipoForanea.add(tipo);
                if (tipo == 'V') {
                    cantidaVDForanea.add(ValidacionDouble());
                }else if (tipo == 'D') {
                    cantidaVDForanea.add(ValidacionDouble());
                }else
                cantidadF--;
                maximoF++;
            }
        }
        Entidad(idForaneas, nombreEntidad, maximo, maximoF, idAtributos, 
                idAtributoForanea, tipoAtributos, tipoForanea, nuloNo, cantidaVD, cantidaVDForanea, foraneaE);
        Limpieza(idForaneas, nombreEntidad, maximo, maximoF, idAtributos, 
                idAtributoForanea, tipoAtributos, tipoForanea, nuloNo, cantidaVD, cantidaVDForanea, foraneaE);
    }
    
    private void Caso2(){
        leer.nextLine();
        System.out.println("---Entidad---");
        System.out.println("---Nombre de la entidad---");
        nombreEntidad = leer.nextLine();
        System.out.println("Ingrese la cantidad de atributos");
        cantidadA = leer.nextInt();
        leer.nextLine();
        System.out.println("Para el tipo de datos solo ingrese");
        System.out.println("la llave primaria ingreselo de primero");
        TipoDato();
        while (cantidadA != 0) {                        
            System.out.println("Nombre del atributo");
            idAtributos.add(leer.nextLine());
            System.out.println("Tipo de atributo");
            char tipo = UnCaracter();
            tipoAtributos.add(tipo);
            if (tipo == 'V') {
                cantidaVD.add(ValidacionDouble());
            }else if (tipo == 'D') {
                cantidaVD.add(ValidacionDouble());
            }else
                cantidaVD.add(0.00);
            cantidadA--;
            maximo++;
        }
        System.out.println("Agrege una palabra para diferenciar");
        System.out.println("los atributos con los metodos");
        caracter = leer.nextLine();
        UnidorProcedimientos(nombreEntidad, maximo, caracter, idAtributos, tipoAtributos, cantidaVD);
        Limpieza(idForaneas, nombreEntidad, maximo, maximoF, idAtributos, 
                idAtributoForanea, tipoAtributos, tipoForanea, nuloNo, cantidaVD, cantidaVDForanea, foraneaE);
    }

}
